import unittest
from website.models import User


class TestEmployee(unittest.TestCase):

    def setUp(self):
        print('setUp')
        self.User_1 = User() #User1
        self.User_2 = User() #User2

    def test_Passwort(self):
        print('test_Passwort')
        self.assertEqual(self.User_1, self.User_2)
        self.assertEqual(self.User_2, self.User_1)

        self.User_1.first = 'Michael' #Atributte User 1
        self.User_2.first = 'David' #Attribute User 2

        self.assertEqual(self.User_1.first, self.User_1.first) #Gleich
        self.assertEqual(self.User_2.first, self.User_2.first) #Gleich
        self.assertEqual(self.User_1.first, self.User_2.first) #Fail Beispiel


if __name__ == '__main__':
    unittest.main()